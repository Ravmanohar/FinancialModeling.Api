﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DBModels
{
    public class PermitInfo
    {
        [Key]
        public int Id { get; set; }
        //public int PermitId { get; set; }
        //public string PermitCode { get; set; }
        //public string PermitName { get; set; }
        public int AnnualCost { get; set; }
        public int QuantitySold { get; set; }
        public int PermitId { get; set; }
    }
}