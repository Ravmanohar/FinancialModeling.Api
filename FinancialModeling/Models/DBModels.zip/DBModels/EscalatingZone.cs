﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DBModels
{
    public class EscalatingZone
    {
        [Key]
        public int Id { get; set; }
        //public int ZoneId { get; set; }
        //public string ZoneCode { get; set; }
        //public string ZoneName { get; set; }
        //public int ClientModelId { get; set; }
        //public int ClientId { get; set; }

        public int NonPeakHourlyRate { get; set; }
        public int NonPeakEscalatingRate { get; set; }
        public int NonPeakHourEscalatingRateBegins { get; set; }
        public int NonPeakDailyMaxOrAllDayRate { get; set; }
        public int NonPeakEveningFlatRate { get; set; }

        public int PeakHourlyRate { get; set; }
        public int PeakEscalatingRate { get; set; }
        public int PeakHourEscalatingRateBegins { get; set; }
        public int PeakDailyMaxOrAllDayRate { get; set; }
        public int PeakEveningFlatRate { get; set; }


        public int NumberOfSpacesPerZone { get; set; }
        public int PercentOfSpaceOccupied { get; set; }
        public int NumberOfSpacesRemaining { get; set; }

        public int CompliancePercentage { get; set; }

        public int NonPeakOccupancyPercentage { get; set; }
        public int PeakOccupancyPercentage { get; set; }

        public int ZoneId { get; set; }//References Zone
    }
}