﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DBModels
{
    public class Zone
    {
        public int ZoneId { get; set; }
        public string ZoneCode { get; set; }
        public string ZoneName { get; set; }
        public int ClientModelId { get; set; }
        public int ClientId { get; set; }
    }
}