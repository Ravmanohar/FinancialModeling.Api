﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DBModels
{
    public class EquipmentCost
    {
        [Key]
        public int EquipmentId { get; set; }
        public int UnitsOwned { get; set; }
        public int UnitsPurchased { get; set; }
        public int CostOfBaseUnit { get; set; }
        public int WarrantyStartingYear { get; set; }
        public int MonthlyMeterSoftwareFees { get; set; }
        public int MonthlyCreditCardProcessingFees { get; set; }
        public int EstimatedCreditCardTransaction { get; set; }

        public int EquipmentTypeId { get; set; }
        public int ClientId { get; set; }
        public string ZoneCode { get; set; }
        public int ParkingTypeId { get; set; }//References LuParkingType
    }
}