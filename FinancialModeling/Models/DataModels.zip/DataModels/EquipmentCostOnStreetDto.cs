﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class EquipmentCostOnStreetDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int QuantityOfUnitsOwned { get; set; }
        public int QuantityOfUnitsPurchased { get; set; }
        public int CostOfBaseUnit { get; set; }
        public int MeterWarranty { get; set; }
        public int MonthlyMeterSoftwareFeesPerUnit { get; set; }
        public int MonthlyCCProcessingFeesPerTransaction { get; set; }
        public int EstimatedNumberOfCreditCardTransPerUnitPerDay { get; set; }
        public bool IsAlternateOption { get; set; }
        public int ClientId { get; set; }
    }
}