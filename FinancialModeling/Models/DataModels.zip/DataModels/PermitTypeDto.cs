﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class PermitTypeDto
    {
        public int permitId { get; set; }
        public string permitName { get; set; }
        public int annualCost { get; set; }
        public int quantitySold { get; set; }
        public int clientId { get; set; }
        public int zoneId { get; set; }
    }
}