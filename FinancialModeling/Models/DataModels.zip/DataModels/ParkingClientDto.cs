﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class ParkingClientDto
    {
        public int clientId { get; set; }
        public string clientName { get; set; }
        public DateTime createDate { get; set; }
        public DateTime modifiedDate { get; set; }
        public string createdBy { get; set; }
        public string modifiedBy { get; set; }
        public int numberOfUsers { get; set; }
        public string createdByName { get; set; }
        public string modifiedByName { get; set; }
    }
}