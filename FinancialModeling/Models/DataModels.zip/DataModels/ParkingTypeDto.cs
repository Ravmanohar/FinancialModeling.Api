﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class ParkingTypeDto
    {
        public int parkingTypeId { get; set; }
        public string parkingTypeName { get; set; }
    }
}