﻿using System;
using System.Collections.Generic;

namespace FinancialModeling.Models
{

    public class SetupClientDto
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public LuParkingType SelectedParkingType { get; set; }
        public List<LuParkingType> ParkingTypeList { get; set; }

        public LuModelType SelectedModelType { get; set; }
        public List<LuModelType> ModelTypeList { get; set; }


        public bool IsPeakSeasonPricing { get; set; }
        public string PeakSeasonPricing { get; set; }

        //public string OperatingHoursStart { get; set; }
        //public string OperatingHoursEnd { get; set; }

        public string PeakSeasonDateRange { get; set; }
        public DateTime PeakSeasonStartDate { get; set; }
        public DateTime PeakSeasonEndDate { get; set; }

        public List<LuDays> SelectedDays { get; set; }
        public List<LuDays> LuDays { get; set; }

        public List<LuHolidays> SelectedHolidays { get; set; }
        public List<LuHolidays> LuHolidays { get; set; }

        public List<OperatingHour> ClientOperatingHours { get; set; }
        public List<ParkingZone> ClientParkingZones { get; set; }
        public List<PermitType> ClientPermitTypes { get; set; }
    }

    public class ClientInfoDto
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public LuParkingType SelectedParkingType { get; set; }

        public LuModelType SelectedModelType { get; set; }

        public bool IsPeakSeasonPricing { get; set; }
        public string PeakSeasonPricing { get; set; }

        //public string OperatingHoursStart { get; set; }
        //public string OperatingHoursEnd { get; set; }

        public string PeakSeasonDateRange { get; set; }
        public DateTime PeakSeasonStartDate { get; set; }
        public DateTime PeakSeasonEndDate { get; set; }

        public List<OperatingDay> OperatingDays { get; set; }
        public List<Holiday> Holidays { get; set; }

        public List<OperatingHour> ClientOperatingHours { get; set; }

        public List<ParkingZone> ClientParkingZones { get; set; }
        public List<PermitType> ClientPermitTypes { get; set; }
    }

    public class Lookups
    {
        public List<LuDays> LuDays { get; set; }
        public List<LuHolidays> LuHolidays { get; set; }
        public List<LuModelType> LuModelTypes { get; set; }
        public List<LuParkingType> LuParkingTypes { get; set; }
    }
}