﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class FinancialDashboardDto
    {
        //NOTE : SetupModel Class name will change to HourlyModelDto
        public SetupModel HourlyOnStreet { get; set; }
        public SetupModel HourlyOffStreet { get; set; }
        public SetupModel HourlyGarages { get; set; }

        //NOTE : SetupModel Class name will change to TimeOfDayModeDto
        public SetupModel TimeOfDayStreet { get; set; }
        public SetupModel TimeOfDayOffStreet { get; set; }
        public SetupModel TimeOfDayGarages { get; set; }

        //NOTE : SetupModel Class name will change to EscalatingModeDto
        public SetupModel EscalatingOnStreet { get; set; }
        public SetupModel EscalatingOffStreet { get; set; }
        public SetupModel EscalatingGarages { get; set; }
    }
}