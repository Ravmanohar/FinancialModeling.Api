﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class OperatingDayDto
    {
        public int dayId { get; set; }
        public string dayName { get; set; }
        public bool isSelected { get; set; }
        public int clientId { get; set; }
        public int zoneId { get; set; }
    }
}