﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class EquipmentCostGaragesDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int QuantityOfUnitsPurchased { get; set; }
        public int GarageAccessPointsIngressEgressQtyOfUnits { get; set; }
        public int IngressEgressEquipmentCostMultispaceMeterCost { get; set; }
        public int PayonFootEquipwithBNA1UnitPerGarage { get; set; }
        public int PayonFootEquipwithCreditCard1UnitPerGarage { get; set; }
        public int AnnualSoftwareFeePerAccessPointUnit { get; set; }
        public int Warranty { get; set; }
        public int MonthlyCCProcessingFeesPerTransaction { get; set; }
        public int EstimatedNumberOfCreditCardTransPerUnitPerDay { get; set; }
        public bool IsAlternateOption { get; set; }
        public int ClientId { get; set; }
    }
}