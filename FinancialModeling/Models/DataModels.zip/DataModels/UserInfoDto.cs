﻿using FinancialModeling.Models.DataModels;
using System;
using System.Collections.Generic;

namespace FinancialModeling.Models
{
    public class UserInfoDto
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public int ClientId { get; set; }
        public UserRoleDto UserRole { get; set; }
    }
}