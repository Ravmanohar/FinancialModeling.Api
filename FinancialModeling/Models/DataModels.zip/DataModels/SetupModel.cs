﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class SetupModel
    {
        public int clientId { get; set; }
        public string clientName { get; set; }
        //public int parkingTypeId { get; set; }
        public ParkingTypeDto selectedParkingType { get; set; }
        //public int modelTypeId { get; set; }
        public ModelTypeDto selectedModelType { get; set; }
        public List<ClientParkingZone> clientParkingZones { get; set; }
    }

    public class ClientParkingZone
    {
        public int zoneId { get; set; }
        public string zoneName { get; set; }
        public int numberOfSpacesPerZone { get; set; }
        public int percentOfSpaceOccupied { get; set; }
        public int CompliancePercentage { get; set; }
        public int PeakSeasonHourlyRate { get; set; }
        public int NonPeakSeasonHourlyRate { get; set; }
        public int avgOccupancyPercentPeak { get; set; }
        public int avgOccupancyPercentNonPeak { get; set; }
        public int clientId { get; set; }
        public bool isPeakSeasonPricing { get; set; }
        public DateTime? peakSeasonStartDate { get; set; }
        public DateTime? peakSeasonEndDate { get; set; }
        public int clientModelId { get; set; }

        public List<OperatingDayDto> clientOperatingDays { get; set; }
        public List<HolidayDto> clientHolidays { get; set; }
        public List<OperatingHourDto> clientOperatingHours { get; set; }
        public List<PermitTypeDto> clientPermitTypes { get; set; }
    }
}