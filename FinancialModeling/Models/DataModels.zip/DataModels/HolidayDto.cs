﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class HolidayDto
    {
        public int holidayId { get; set; }
        public string eventName { get; set; }
        public bool isSelected { get; set; }
        public int clientId { get; set; }
        public int zoneId { get; set; }
    }
}