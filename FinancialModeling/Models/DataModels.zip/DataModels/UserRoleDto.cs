﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class UserRoleDto
    {
        public string RoleId { get; set; }
        public string RoleName { get; set; }
    }
}