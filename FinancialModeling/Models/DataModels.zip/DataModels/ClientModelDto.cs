﻿using System;

namespace FinancialModeling.Models.DataModels
{
    public class ClientModelDto
    {
        public int ClientModelId { get; set; }
        public int ClientId { get; set; }
        public int ParkingTypeId { get; set; }
        public int ModelTypeId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string ParkingTypeName { get; set; }
        public string ModelTypeName { get; set; }
        public string ModelName { get; set; }
        public string CreatedByName { get; set; }
        public string ModifiedByName { get; set; }
    }

    public class ParkingModelCombinationsDto
    {
        public int ClientModelId { get; set; }
        public string CombinationName { get; set; }
        public int ParkingTypeId { get; set; }
        public string ParkingTypeName { get; set; }
        public int ModelTypeId { get; set; }
        public string ModelTypeName { get; set; }
        public int ClientId { get; set; }
        public bool IsCreated { get; set; }
    }
}