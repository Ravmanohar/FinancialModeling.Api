﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models
{
    public class SetupModel
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public int parkingTypeId { get; set; }
        public LuParkingType SelectedParkingType { get; set; }
        public int modelTypeId { get; set; }
        public LuModelType SelectedModelType { get; set; }


        public bool IsPeakSeasonPricing { get; set; }
        public string PeakSeasonPricing { get; set; }

        //public string OperatingHoursStart { get; set; }
        //public string OperatingHoursEnd { get; set; }

        public string PeakSeasonDateRange { get; set; }
        public DateTime PeakSeasonStartDate { get; set; }
        public DateTime PeakSeasonEndDate { get; set; }

        public List<LuDays> SelectedDays { get; set; }
        public List<LuDays> LuDays { get; set; }

        public List<LuHolidays> SelectedHolidays { get; set; }
        public List<LuHolidays> LuHolidays { get; set; }

        public List<OperatingHour> ClientOperatingHours { get; set; }
        public List<ParkingZone> ClientParkingZones { get; set; }
        public List<PermitType> ClientPermitTypes { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }
}