﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class ModelTypeDto
    {
        public int modelTypeId { get; set; }
        public string modelTypeName { get; set; }
    }
}