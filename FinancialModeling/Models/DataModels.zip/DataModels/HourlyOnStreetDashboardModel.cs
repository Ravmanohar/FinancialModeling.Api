﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class HourlyOnStreetDashboardModel
    {
        public string RevenueOfYear { get; set; }
        public List<Zone> Zones { get; set; }
    }

    public class Zone
    {
        public string ZoneName { get; set; }
        public int Hourly { get; set; }
        public int Permit { get; set; }
        public int Total { get; set; }
    }
}