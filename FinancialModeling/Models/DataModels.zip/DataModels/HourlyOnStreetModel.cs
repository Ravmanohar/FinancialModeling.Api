﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinancialModeling.Models.DataModels
{
    public class HourlyOnStreetModel
    {
        public ZoneModelDto ZoneInfo { get; set; }
        public PermitDto PermitInfo { get; set; }

    }

    public class ZoneModelDto
    {
        public int TotalZones { get; set; }
        public ZoneLabelDto LableDescriptions { get; set; }
        public List<ZoneDto> Zones { get; set; }
    }

    public class ZoneLabelDto
    {
        public string NonPeakSeasonHourlyRate { get; set; }
        public string PeakSeasonHourlyRate { get; set; }
        public string NumberOfSpacesPerZone { get; set; }
        public string PercentOfSpaceOccupied { get; set; }
        public string NumberOfSpacesRemaining { get; set; }
    }

    public class ZoneDto
    {
        public int ZoneId { get; set; }
        public string ZoneName { get; set; }
        public int NonPeakSeasonHourlyRate { get; set; }
        public int PeakSeasonHourlyRate { get; set; }
        public int NumberOfSpacesPerZone { get; set; }
        public int PercentOfSpaceOccupied { get; set; }
        public int NumberOfSpacesRemaining { get; set; }
        public int AvgOccupancyPercentPeak { get; set; }
        public int AvgOccupancyPercentNonPeak { get; set; }
        public DaysPerYearDto DaysPerYear { get; set; }
        public HoursOfOperationDaily HoursOfOperationDaily { get; set; }
        public CompliancePercentage CompliancePercentage { get; set; }
    }

    public class DaysPerYearDto
    {
        public string Label { get; set; }
        public DaysDto Total { get; set; }
        public DaysDto Peak { get; set; }
        public DaysDto NonPeak { get; set; }
    }

    public class DaysDto
    {
        public int Days { get; set; }
        public string Label { get; set; }
    }

    public class CompliancePercentage
    {
        public int Percentage { get; set; }
        public string Lable { get; set; }
    }

    public class HoursOfOperationDaily
    {
        public string Label { get; set; }
        public HourseDto Total { get; set; }
        public HourseDto Start { get; set; }
        public HourseDto End { get; set; }
    }

    public class HourseDto
    {
        public int Value { get; set; }
        public string Lable { get; set; }
    }

    public class PermitDto
    {
        public PermitLabelDto LableDescriptions { get; set; }
        public List<PermitZoneDto> Zones { get; set; }
    }

    public class PermitLabelDto
    {
        public string QuantitySoldResidentialPermit { get; set; }
        public string CostPerMonthForResidentialPermit { get; set; }
        public string QuantitySoldEmployeePermit { get; set; }
        public string CostPerMonthForEmployeePermit { get; set; }
    }

    public class PermitZoneDto
    {
        public int ZoneId { get; set; }
        public string ZoneName { get; set; }
        public int PermitId { get; set; }
        public int QuantitySoldResidentialPermit { get; set; }
        public int CostPerMonthForResidentialPermit { get; set; }
        public int QuantitySoldEmployeePermit { get; set; }
        public int CostPerMonthForEmployeePermit { get; set; }
    }
}